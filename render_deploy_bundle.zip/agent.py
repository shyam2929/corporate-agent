# -*- coding: utf-8 -*-
import os
import re
import json
from typing import Dict, Any, List

LEARNED_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "learned_knowledge.json")
UNRESOLVED_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "unresolved_queries.json")

class CorporateFactoryAgent:
    def __init__(self):
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.learned_qa: Dict[str, str] = self._load_learned_qa()

    def _load_learned_qa(self) -> Dict[str, str]:
        if os.path.exists(LEARNED_FILE):
            try:
                with open(LEARNED_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading learned QA: {e}")
        return {}

    def save_learned_qa(self):
        try:
            with open(LEARNED_FILE, "w", encoding="utf-8") as f:
                json.dump(self.learned_qa, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving learned QA: {e}")

    def learn_from_owner(self, query: str, answer: str):
        cleaned_q = query.strip().lower()
        cleaned_a = answer.strip()
        if cleaned_q and cleaned_a:
            self.learned_qa[cleaned_q] = cleaned_a
            self.save_learned_qa()
            print(f"[SELF-LEARNING] Learned new Q&A pair: '{cleaned_q[:50]}' -> '{cleaned_a[:50]}...'")

    def record_unresolved_query(self, user_id: str, query: str):
        queries = []
        if os.path.exists(UNRESOLVED_FILE):
            try:
                with open(UNRESOLVED_FILE, "r", encoding="utf-8") as f:
                    queries = json.load(f)
            except:
                pass
        queries.append({"user_id": user_id, "query": query})
        with open(UNRESOLVED_FILE, "w", encoding="utf-8") as f:
            json.dump(queries, f, indent=2, ensure_ascii=False)

    def get_or_create_session(self, user_id: str) -> Dict[str, Any]:
        if user_id not in self.sessions:
            self.sessions[user_id] = {
                "state": "INIT",
                "accounts_count": None,
                "daily_limit": None,
                "banks": [],
                "last_query": None,
                "history": []
            }
        return self.sessions[user_id]

    def reset_session(self, user_id: str):
        if user_id in self.sessions:
            del self.sessions[user_id]

    def reply(self, user_id: str, message: str) -> str:
        msg = message.strip()
        session = self.get_or_create_session(user_id)
        session["last_query"] = msg
        session["history"].append({"role": "user", "content": msg})

        response = self._process_message(session, user_id, msg)
        session["history"].append({"role": "assistant", "content": response})
        return response

    def _process_message(self, session: Dict[str, Any], user_id: str, msg: str) -> str:
        msg_lower = msg.lower()

        # Check Learned Knowledge first
        for learned_q, learned_a in self.learned_qa.items():
            q_words = set(re.findall(r'\w+', learned_q))
            msg_words = set(re.findall(r'\w+', msg_lower))
            if q_words and len(q_words.intersection(msg_words)) / len(q_words) >= 0.7:
                return learned_a

        # Account details parsing
        parsed_data = self._extract_account_details(msg_lower)
        if parsed_data.get("has_info") and (parsed_data.get("accounts") or parsed_data.get("limit")):
            if parsed_data.get("accounts"):
                session["accounts_count"] = parsed_data["accounts"]
            if parsed_data.get("limit"):
                session["daily_limit"] = parsed_data["limit"]
            if parsed_data.get("banks"):
                session["banks"].extend(parsed_data["banks"])

            session["state"] = "QUALIFIED"
            return (
                "Thank you for sharing your account details!\n\n"
                f"We have noted: {session.get('accounts_count') or 'Multiple'} account(s) "
                f"with {', '.join(set(session.get('banks', []))) if session.get('banks') else 'RBI-registered entities'}, "
                f"daily processing capacity: {session.get('daily_limit') or 'High turnover'}.\n\n"
                "**Next Step - Onboarding Path**:\n"
                "1. **Instant Digital Onboarding (With Security Deposit)**: Start immediately with live transaction routing and 2.5% daily settlements.\n"
                "2. **Face-to-Face (F2F) Verification (Without Deposit)**: In-person onboarding available in **Jaipur**, **Mumbai**, **Chennai**, **Bangalore**, or **Kathmandu**.\n"
                "*(Important Perk: Corporate Factory sponsors 100% of your travel and luxury hotel stay for ALL meeting locations!)*\n\n"
                "Which option works best for you: **Digital with deposit** or **F2F (Travel & Luxury Stay Covered)**?"
            )

        # Check FAQ
        faq_response = self._match_faq(msg_lower)
        if faq_response:
            return faq_response

        # Greeting
        if self._is_greeting(msg_lower):
            if session["state"] == "INIT":
                session["state"] = "INTAKE_QUESTIONING"
                return (
                    "Hello there! Welcome to **Corporate Factory**.\n\n"
                    "We are India's premier B2B corporate settlement network partnering with high-traffic enterprise and iGaming platforms. "
                    "We offer a standard **2.5% payout commission** with a **0.015% ultra-low dispute record** and **100% financial guarantee**.\n\n"
                    "**Every RBI-registered bank or financial entity is 100% eligible** for partnership.\n\n"
                    "For the next step, please answer a few quick questions so I understand what you are ready to start with:\n"
                    "1. **How many accounts** do you have available?\n"
                    "2. **What's your daily turnover limit** that you can process?\n"
                    "3. **Which RBI-registered banks** are these accounts with (e.g. HDFC, IndusInd, SBI, BOI, Bandhan, Fino, NSDL, JioFinance, etc.)?"
                )
            else:
                return (
                    "Hello! Glad to connect again. Please share your account bank names and daily transaction limits "
                    "so we can allocate volume to your accounts right away."
                )

        self.record_unresolved_query(user_id, msg)
        return (
            "Understood! To proceed with Corporate Factory:\n\n"
            "• **Commission Rate**: Flat **2.5% payout** on verified turnover volume with daily prompt settlements.\n"
            "• **Eligible Institutions**: **Every RBI-registered financial entity is eligible**.\n"
            "• **Funds Nature**: Enterprise iGaming & digital merchant routing with a **0.015% chargeback record**.\n"
            "• **Security**: **100% financial guarantee** on disputes, resolved in **25 days**.\n"
            "• **Onboarding**: Instant digital (with security deposit) OR Face-to-Face in Jaipur, Mumbai, Chennai, Bangalore, or Kathmandu (without deposit, **100% travel & luxury hotel stay sponsored for all locations**).\n\n"
            "Please share: **How many accounts do you have, with which banks, and what daily limits?**"
        )

    def _is_greeting(self, text: str) -> bool:
        greetings = ["hi", "hello", "hey", "namaste", "salaam", "bhai", "bro", "sir", "start", "interested", "partner", "connect", "mega account"]
        words = set(re.findall(r'\b[a-z]+\b', text))
        return bool(words.intersection(greetings)) and len(text.split()) <= 6

    def _match_faq(self, text: str) -> str:
        if any(k in text for k in ["commission", "payout", "rate kya", "kitna rate", "kitna milega", "percentage", "margin", "payouts", "percent", "charges"]):
            return (
                "**Commission & Payout Terms**:\n\n"
                "• **Rate**: Flat **2.5% payout commission** on processed transaction turnover volume.\n"
                "• **Settlement**: Daily prompt settlements with instant statement reconciliation.\n"
                "• **Volume Priority**: High-turnover accounts (from ₹5 Lakhs to ₹1 Crore+ daily) receive top routing priority.\n\n"
                "Please share your account count and daily limits to allocate volume to your accounts."
            )

        if any(k in text for k in ["ye funds ka kya", "nature of fund", "funds kya hai", "source of fund", "kiska paisa", "kaha se aayega", "igaming", "gaming", "work kya hai"]):
            return (
                "**Nature of Funds & Operations**:\n\n"
                "We are partnered with high-traffic **iGaming platforms** and enterprise digital merchants, where risk management and payment reliability are paramount.\n\n"
                "• **Negligible Chargebacks**: Our operation maintains an exceptional track record with a negligible chargeback rate of just **0.015%**.\n"
                "• **100% Financial Guarantee**: Building on this confidence, in the unlikely event that a chargeback or dispute does occur, our company assumes **100% of the responsibility**, with any potential disputes fully resolved within a strict **25-day window**.\n"
                "• **Robust Verification**: Multi-tier fraud-prevention measures are active across all our networks."
            )

        if any(k in text for k in ["without deposit", "bina deposit", "no deposit", "deposit kitna", "deposit mandatory", "security deposit", "how much deposit", "deposit ke bina"]):
            return (
                "**Deposit & Onboarding Policy**:\n\n"
                "We operate with two clear options:\n"
                "1. **Without Deposit (F2F Mandatory)**: If you start without a security deposit, Face-to-Face physical verification is mandatory. "
                "Available in **Jaipur**, **Mumbai**, **Chennai**, **Bangalore**, and **Kathmandu**.\n"
                "*(Important Perk: Corporate Factory covers **100% of your travel and luxury accommodation for ALL meeting locations** once your account limits are confirmed!)*\n\n"
                "2. **With Security Deposit**: 100% instant digital onboarding with immediate liquidity routing.\n\n"
                "Which option works best for you: **Digital with deposit** or **F2F (Travel & Hotel Covered)**?"
            )

        if any(k in text for k in ["freeze", "hold", "dispute", "cyber", "chargeback", "risk", "guarantee", "safe", "legal", "security"]):
            return (
                "**Risk Management & Financial Guarantee**:\n\n"
                "Our operation boasts an exceptional track record, maintaining a negligible chargeback rate of just **0.015%**.\n\n"
                "This ultra-low percentage reflects the robust verification and fraud-prevention measures we have in place across our networks. "
                "Building on this confidence, we offer a **complete financial guarantee**: in the unlikely event that a chargeback does occur, "
                "our company assumes **100% of the responsibility**, with any potential disputes fully resolved within a **25-day window**."
            )

        if any(k in text for k in ["f2f", "face to face", "meeting", "jaipur", "mumbai", "bangalore", "chennai", "kathmandu", "kaha milna", "office address", "location", "stay"]):
            return (
                "**Face-to-Face (F2F) Verification Cities & VIP Hospitality**:\n\n"
                "We conduct in-person verification meetings in:\n"
                "• **Jaipur**\n"
                "• **Mumbai**\n"
                "• **Bangalore**\n"
                "• **Chennai**\n"
                "• **Kathmandu**\n\n"
                "🌟 **100% Sponsored Travel & Stay**: Corporate Factory sponsors **100% of your flights/travel and luxury hotel stay across ALL of these locations** once account eligibility is confirmed!\n\n"
                "To schedule F2F, please share: **How many accounts do you have, with which banks, and what daily limits?**"
            )

        if any(k in text for k in ["which bank", "kaunse bank", "bank list", "supported bank", "rbi", "eligible", "hdfc", "indusind", "sbi", "fino", "bandhan", "nsdl", "jio"]):
            return (
                "**Supported Institutions & Eligibility**:\n\n"
                "✅ **Every RBI-registered financial entity is 100% eligible!**\n\n"
                "This includes all:\n"
                "• **Major Commercial Banks**: HDFC Bank, IndusInd Bank, State Bank of India (SBI), Bank of India (BOI), ICICI, Axis, Kotak, PNB, Canara, etc.\n"
                "• **Payments Banks & Fintechs**: Bandhan Bank, Fino Payments Bank, NSDL Payments Bank, JioFinance, Airtel Payments Bank, etc.\n\n"
                "Current Accounts (Proprietorship, Partnership, Pvt Ltd) and Corporate Banking / CMS accounts with high daily turnover limits are welcomed."
            )

        if any(k in text for k in ["minimum turnover", "daily limit", "kitna limit", "minimum limit", "kitna transaction", "mega account"]):
            return (
                "**Daily Limits & Account Scale**:\n\n"
                "We cater to **Mega Accounts** capable of daily turnover from **₹5 Lakhs to ₹1 Crore+** per account.\n"
                "Higher limit accounts receive priority allocation, expedited payouts, and dedicated relationship management.\n\n"
                "How much daily turnover can your accounts comfortably handle?"
            )

        return ""

    def _extract_account_details(self, text: str) -> Dict[str, Any]:
        info = {"has_info": False, "accounts": None, "limit": None, "banks": []}
        banks_list = ["hdfc", "indusind", "sbi", "state bank", "bank of india", "boi", "bandhan", "fino", "nsdl", "jio", "icici", "axis", "kotak", "pnb", "canara", "yes bank", "rbi"]
        for b in banks_list:
            if b in text:
                info["banks"].append(b.upper())
                info["has_info"] = True

        acc_match = re.search(r'(\d+)\s*(?:accounts?|acc|khate|a\/c)', text)
        if acc_match:
            info["accounts"] = int(acc_match.group(1))
            info["has_info"] = True

        limit_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:lakh|lac|cr|crore|k|m|l)\b', text)
        if limit_match:
            info["limit"] = limit_match.group(0).upper()
            info["has_info"] = True

        return info
