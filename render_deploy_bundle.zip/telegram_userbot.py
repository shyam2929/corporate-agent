# -*- coding: utf-8 -*-
"""
Corporate Factory Live Telegram Auto-Responder & Self-Learning Userbot
Directly connects to your personal Telegram Account (@corporatefactory)
1. Automatically replies to ANY sender messaging your account with self-curated answers.
2. Self-Learns from YOU: Whenever you manually reply to a partner, the agent captures
   the question and your reply, permanently learning it for future senders!
"""

import os
import sys

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import asyncio
import logging
import re
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from agent import CorporateFactoryAgent

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger("CorporateFactoryUserbot")

agent = CorporateFactoryAgent()

# Official Telegram Client credentials fallback if not provided
DEFAULT_API_ID = 2040
DEFAULT_API_HASH = "b18441a1ff607e10a989891a5462e627"

API_ID = os.environ.get("TG_API_ID") or (sys.argv[1] if len(sys.argv) > 1 else str(DEFAULT_API_ID))
API_HASH = os.environ.get("TG_API_HASH") or (sys.argv[2] if len(sys.argv) > 2 else DEFAULT_API_HASH)
PHONE = os.environ.get("TG_PHONE") or (sys.argv[3] if len(sys.argv) > 3 else None)
SESSION_STRING = os.environ.get("TG_SESSION_STRING")

SESSION_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "corporate_factory_session")
HTTP_PORT = int(os.environ.get("PORT", "8080"))

# Store recent incoming sender queries per chat to enable self-learning
recent_incoming_queries = {}

async def start_health_server():
    async def handle_http(reader, writer):
        try:
            await reader.read(1024)
            resp = (
                b"HTTP/1.1 200 OK\r\n"
                b"Content-Type: application/json\r\n"
                b"Connection: close\r\n\r\n"
                b'{"status":"healthy","agent":"CorporateFactory"}\n'
            )
            writer.write(resp)
            await writer.drain()
        except Exception:
            pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    try:
        server = await asyncio.start_server(handle_http, "0.0.0.0", HTTP_PORT)
        logger.info(f"Health check HTTP server active on port {HTTP_PORT} (24/7 cloud keepalive)")
        return server
    except Exception as e:
        logger.warning(f"Could not bind health server on port {HTTP_PORT}: {e}")
        return None

async def main():
    print("="*70)
    print("  CORPORATE FACTORY - SELF-LEARNING TELEGRAM AUTO-RESPONDER")
    print("="*70)
    print(f"Connecting to Telegram with API_ID: {API_ID}...")

    session_target = StringSession(SESSION_STRING.strip()) if SESSION_STRING else SESSION_FILE
    client = TelegramClient(
        session_target,
        int(API_ID),
        API_HASH,
        device_model="CorporateFactory-Server",
        system_version="Windows 10",
        app_version="5.0.0"
    )

    # 1. Self-Learning Handler: Listens to OUTGOING messages sent by YOU (Shyam)
    @client.on(events.NewMessage(outgoing=True, func=lambda e: e.is_private))
    async def on_owner_manual_reply(event):
        try:
            chat_id = str(event.chat_id)
            owner_text = event.raw_text.strip()

            # Check if Shyam sent a manual learning command: e.g. !learn "question" -> "answer"
            if owner_text.startswith("!learn"):
                match = re.search(r"""!learn\s+["'](.*?)["']\s*(?:->|=)\s*["'](.*?)["']""", owner_text, re.DOTALL)
                if match:
                    q, a = match.groups()
                    agent.learn_from_owner(q, a)
                    await event.reply(f"✅ Learned successfully! I will now reply to: '{q}' with your exact answer.")
                    return

            # Passive Human-in-the-Loop Learning:
            # If the partner asked a question and Shyam manually replied to them:
            if chat_id in recent_incoming_queries:
                partner_query = recent_incoming_queries[chat_id]
                # Learn the pair if it's a substantive answer
                if len(owner_text) > 5 and not owner_text.startswith("/"):
                    agent.learn_from_owner(partner_query, owner_text)
                    logger.info(f"🧠 [SELF-LEARNED] Captured owner's manual answer for: '{partner_query}'")

        except Exception as e:
            logger.error(f"Error in owner learning handler: {e}")

    # 2. Auto-Reply Handler: Listens to INCOMING messages sent by any partner/sender
    @client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
    async def on_incoming_partner_message(event):
        try:
            sender = await event.get_sender()
            sender_id = str(sender.id)
            sender_name = f"{getattr(sender, 'first_name', '')} {getattr(sender, 'last_name', '')}".strip()
            username = getattr(sender, 'username', '')
            text = event.raw_text.strip()

            if not text:
                return

            chat_id = str(event.chat_id)
            recent_incoming_queries[chat_id] = text

            logger.info(f"📩 [INCOMING DM] From: {sender_name} (@{username} | ID: {sender_id}) -> '{text}'")

            # Small human-like typing delay (1 second)
            async with client.action(event.chat_id, 'typing'):
                await asyncio.sleep(1.0)

            # Get self-curated answer
            reply_text = agent.reply(sender_id, text)

            # Send reply in Telegram
            await event.reply(reply_text)
            logger.info(f"⚡ [AUTO-REPLIED] To {sender_name} (@{username})")

        except Exception as e:
            logger.error(f"Error handling incoming message: {e}")

    # Start HTTP Health Server for Cloud Keep-Alive
    health_server = await start_health_server()

    # Start the client
    await client.connect()
    if not await client.is_user_authorized():
        logger.info("Session not authorized. Starting interactive authentication...")
        await client.start(phone=PHONE)
    me = await client.get_me()

    account_name = f"@{me.username or me.phone} ({me.first_name})"
    logger.info("="*70)
    logger.info(f"LIVE & ACTIVE: Corporate Factory Agent running on account: {account_name}")
    logger.info("• Auto-Replies to ALL incoming private messages instantly.")
    logger.info("• Self-Learning Active: Whenever you manually reply to any message, the agent learns it automatically!")
    logger.info("• Manual Learn Command: Type in any chat: !learn \"question\" -> \"answer\"")
    logger.info("="*70)

    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
