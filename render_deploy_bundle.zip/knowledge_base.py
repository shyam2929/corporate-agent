# -*- coding: utf-8 -*-
BRAND_INFO = {
    "name": "Corporate Factory",
    "tagline": "Built for Businesses Ahead",
    "handle": "@corporatefactory",
    "email": "corporatefactory1@gmail.com",
    "channel": "https://t.me/corporatefactory",
    "core_business": "High-volume B2B payment settlement and corporate account routing network for high-traffic platforms and enterprise iGaming operators."
}

COMMERCIAL_TERMS = {
    "commission_rate": "2.5%",
    "commission_description": "2.5% payout commission on verified processed turnover volume for qualified corporate and current accounts.",
    "settlement_cycle": "Daily prompt settlements with instant statement reconciliation.",
    "min_daily_limit": "5 Lakhs to 1 Crore+ INR daily turnover capacity per account (Mega Accounts preferred)."
}

SECURITY_AND_RISK = {
    "chargeback_rate": "0.015%",
    "chargeback_description": "Exceptional track record maintaining an ultra-low negligible chargeback rate of just 0.015% across all routing networks.",
    "financial_guarantee": "100% financial guarantee: in the unlikely event a dispute or chargeback occurs, Corporate Factory assumes 100% of the financial liability.",
    "dispute_window": "All disputes and potential claims are fully resolved within a strict 25-day window.",
    "risk_mitigation": "Strict multi-tier verification and fraud-prevention filters ensure clean transaction flow."
}

ONBOARDING_POLICIES = {
    "with_deposit": {
        "type": "Security Deposit Model",
        "details": "Instant digital onboarding with zero travel required. Security deposit secures liquidity and unlocks immediate live transaction routing."
    },
    "without_deposit": {
        "type": "Face-to-Face (F2F) Verification Model",
        "details": "Without security deposit, Face-to-Face (F2F) physical onboarding is mandatory for risk compliance.",
        "f2f_cities": ["Jaipur", "Mumbai", "Chennai", "Bangalore", "Kathmandu"],
        "all_locations_perk": "100% of your travel and luxury accommodation is sponsored by Corporate Factory for ALL meeting locations (Jaipur, Mumbai, Chennai, Bangalore, Kathmandu) once your account eligibility and limits are confirmed!"
    }
}

SUPPORTED_INSTITUTIONS = {
    "eligibility_rule": "Every RBI-registered financial entity is 100% eligible.",
    "common_examples": [
        "HDFC Bank", "IndusInd Bank", "State Bank of India (SBI)", "Bank of India (BOI)",
        "Bandhan Bank", "Fino Payments Bank", "NSDL Payments Bank", "JioFinance",
        "ICICI Bank", "Axis Bank", "Kotak Mahindra Bank", "Yes Bank", "IDFC First Bank",
        "Punjab National Bank (PNB)", "Canara Bank", "Union Bank of India",
        "All RBI-licensed Scheduled Commercial & Payments Banks"
    ]
}

QUALIFICATION_QUESTIONS = [
    "1. How many accounts do you have available right now?",
    "2. What is the daily turnover limit that you can comfortably process per account?",
    "3. Which RBI-registered banks or financial entities are these accounts with?"
]
